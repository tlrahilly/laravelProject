<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;

class EmployeeController extends Controller
{
    public function index()
    {
      $employees = Employee::all();
      return view('employee.index', ['employees'=>$employees]);
    }

    public function create()
    {
      return view('employee.create');
    }

    public function store(Request $request)
    {
      $employee = new Employee();

      $employee->firstName = $request->input('firstname');
      $employee->lastName = $request->input('lastname');
      $employee->phoneNumber = $request->input('phone');
      $employee->description = $request->input('description');
      $employee->save();
      return redirect()->route('employees.index')->with('info','Employee Added Successfully');
    }

    public function edit($id)
    {
      $employee = Employee::find($id);
      return view('employee.edit', ['employee'=>$employee]);
    }

    public function update(Request $request)
    {
      $employee = Employee::find($request->input('id'));
      $employee->firstName = $request->input('firstname');
      $employee->lastName = $request->input('lastname');
      $employee->description = $request->input('description');
      $employee->phoneNumber = $request->input('phone');
      $employee->save(); //persist the data
      return redirect()->route('employees.index')->with('info','Employee Updated Successfully');
    }

    public function destroy($id)
    {
        //Retrieve the employee
        $employee = Employee::find($id);
        //delete
        $employee->delete();
        return redirect()->route('employees.index');
    }
}
