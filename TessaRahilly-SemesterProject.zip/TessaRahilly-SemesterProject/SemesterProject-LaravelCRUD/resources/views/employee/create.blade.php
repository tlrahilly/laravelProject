@extends('layouts.master')
@section('title','Create Employee')
@section('content')
<aside class="padding">
  <ul>
    <li><a href="{{ url('/') }}"><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i><p>Home</p></a></li>
    <li style="border-top: none;"><a href="{{route('employees.index')}}"><i class="fa fa-users fa-2x" aria-hidden="true"></i><p>View People</p></a></li>
    <li class="active"><a href="{{route('employees.create')}}"><i class="fa fa-user-plus fa-2x" aria-hidden="true"></i><p>Add Person</p></a></li>
  </ul>
</aside>
<main>
  <h1 id="create-title">Create A New Person</h1>
  <div class="row mt-5">
    <div class="col-sm-8 create-form">
      <form action="{{route('employees.store')}}" method = "post">
        @csrf
        <div class="form-group">
          <label for="firstname">Firstname:</label>
          <input type="text" name = "firstname" id = "firstname" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="lastname">Lastname:</label>
          <input type="text" name = "lastname" id = "lastname" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="phone">Phone Number:</label>
          <input type="text" name = "phone" id = "phone" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="department">Description:</label>
          <textarea class="form-control" style="height:150px" name="description" id = "description" placeholder="Description" required></textarea>
        </div>
        <button type = "submit" class = "btn btn-info">Add</button>
      </form>
    </div>
  </div>
</main>
@endsection
