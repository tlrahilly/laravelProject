@extends('layouts.master')
@section('title','Employees Index')
@section('content')
<aside class="padding">
  <ul>
    <li><a href="{{ url('/') }}"><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i><p>Home</p></a></li>
    <li class="active"><a href="{{route('employees.index')}}"><i class="fa fa-users fa-2x" aria-hidden="true"></i><p>View Contact</p></a></li>
    <li><a href="{{route('employees.create')}}"><i class="fa fa-user-plus fa-2x" aria-hidden="true"></i><p>Add Contact</p></a></li>
  </ul>
</aside>
<main>
  <div class="row">
    <div class="col-sm-12 row more-padding">
      @foreach($employees as $employee)
      <div class="col-sm-4 even-more-padding">
        <div class="card">
          <div class="card-img-top"></div>
          <div class="card-body">
            <h4 class="card-title">{{ $employee->firstName }} {{ $employee->lastName }}</h4>
            <div class="row caption">
              <p>ID: <span>{{ $employee->id }}</span></p>
              <p>Phone: <span>{{ $employee->phoneNumber}}</span></p>
            </div>
            <p class="card-text">
              {{ $employee->description }}
            </p>

          </div>
          <div class="row options">
            <a href="{{route('employees.edit',['id'=>$employee->id])}}" class = "btn btn-info">Edit</a>
            <a href="{{route('employees.destroy',['id'=>$employee->id])}}" class = "btn btn-danger">Delete</a>

          </div>
        </div>
      </div>
      @endforeach
    </div>
  </div>
</main>
@endsection
