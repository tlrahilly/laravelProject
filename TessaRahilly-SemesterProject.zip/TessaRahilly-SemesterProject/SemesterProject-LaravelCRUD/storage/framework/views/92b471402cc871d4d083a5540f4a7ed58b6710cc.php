<?php $__env->startSection('title','Laravel CRUD'); ?>
<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('employees.index')); ?>">View Contacts</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('employees.create')); ?>">Add Contact</a>
      </li>
    </ul>
  </div>
</nav>
<main class="no-aside">
  <!--title section-->
  <div class="col-sm-12 splash-p">
    <div class="row splash-screen">
      <div class="col-sm-6">
        <h1>Lots of People -<br> One place to store them!</h1>
        <p>Storing contacts has just became a whole lot easier.</p>
      </div>
      <div class="col-sm-6">
        <img src="images/titel-img.png" alt="" />
      </div>
    </div>
    <div class="splash-info">
      <h1>Never Lose a Number Again</h1>
      <div class="">
        <div class="row">
          <div class="row col info">
            <div>
              <img src="images/number.png" alt="" />
            </div>
            <div class="">
              <h2>Numbers</h2>
              <p>We let you store your contacts number for easy access at a later date.</p>
            </div>
          </div>
          <div class="row col info">
            <div>
              <img src="images/people.png" alt="" />
            </div>
            <div class="">
              <h2>Names</h2>
              <p>You can store the full name of your contacts in our system.</p>
            </div>
          </div>
          <div class="row col info">
            <div>
              <img src="images/description.png" alt="" />
            </div>
            <div class="">
              <h2>Descriptions</h2>
              <p>Give a short description of your contact so that know who your calling.</p>
            </div>
          </div>
        </div>
        <div class="row info-block">
          <div class="row col info">
            <div>
              <img src="images/add.png" alt="" />
            </div>
            <div class="">
              <h2>Add</h2>
              <p>Add as many contacts as you want to our list of people here.</p>
            </div>
          </div>
          <div class="row col info">
            <div>
              <img src="images/edit.png" alt="" />
            </div>
            <div class="">
              <h2>Edit</h2>
              <p>If you need to change a contacts info then you go right ahead and do it.</p>
            </div>
          </div>
          <div class="row col info">
            <div>
              <img src="images/delete.png" alt="" />
            </div>
            <div class="">
              <h2>Delete</h2>
              <p>No longer a friend? Then you can delete that person from ever being there.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapps\SemesterProject\resources\views/welcome.blade.php ENDPATH**/ ?>