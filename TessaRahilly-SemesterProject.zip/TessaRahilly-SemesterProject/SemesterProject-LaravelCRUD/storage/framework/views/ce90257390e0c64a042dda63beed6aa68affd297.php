<?php $__env->startSection('title','Employees Index'); ?>
<?php $__env->startSection('content'); ?>
<aside class="padding">
  <ul>
    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i><p>Home</p></a></li>
    <li class="active"><a href="<?php echo e(route('employees.index')); ?>"><i class="fa fa-users fa-2x" aria-hidden="true"></i><p>View Contact</p></a></li>
    <li><a href="<?php echo e(route('employees.create')); ?>"><i class="fa fa-user-plus fa-2x" aria-hidden="true"></i><p>Add Contact</p></a></li>
  </ul>
</aside>
<main>
  <div class="row">
    <div class="col-sm-12 row more-padding">
      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-4 even-more-padding">
        <div class="card">
          <div class="card-img-top"></div>
          <div class="card-body">
            <h4 class="card-title"><?php echo e($employee->firstName); ?> <?php echo e($employee->lastName); ?></h4>
            <div class="row caption">
              <p>ID: <span><?php echo e($employee->id); ?></span></p>
              <p>Phone: <span><?php echo e($employee->phoneNumber); ?></span></p>
            </div>
            <p class="card-text">
              <?php echo e($employee->description); ?>

            </p>

          </div>
          <div class="row options">
            <a href="<?php echo e(route('employees.edit',['id'=>$employee->id])); ?>" class = "btn btn-info">Edit</a>
            <a href="<?php echo e(route('employees.destroy',['id'=>$employee->id])); ?>" class = "btn btn-danger">Delete</a>

          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapps\SemesterProject\resources\views/employee/index.blade.php ENDPATH**/ ?>